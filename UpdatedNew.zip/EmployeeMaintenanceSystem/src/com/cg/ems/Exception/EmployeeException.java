package com.cg.ems.Exception;

public class EmployeeException extends Exception {
	public EmployeeException(String msg)
	{
		super(msg);
	}
}
