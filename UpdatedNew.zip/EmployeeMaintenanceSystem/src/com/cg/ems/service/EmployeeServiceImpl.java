package com.cg.ems.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.chrono.ChronoLocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ems.Exception.EmployeeException;
import com.cg.ems.beans.EmployeeDetails;
import com.cg.ems.beans.UserMaster;
import com.cg.ems.dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService
{
	EmployeeDaoImpl daoObj=null;

	public EmployeeServiceImpl() {
		daoObj= new EmployeeDaoImpl();
	}

	// implementing getAppointmentID()
	
	// this method validates User name
		public boolean validateName(String str)
		{
	    String namePattern = "[A-Za-z ]{6,20}";
		if(Pattern.matches(namePattern,str))
			return true;
		else
			return false;
		}
		
		// this method validates User phone number
		public boolean validatePhoneNumber(String str)
		{
			if(Pattern.matches("[7-9][0-9]{9}",str))
				return true;
			else
				return false;	
		}
		
		// this method validates given mobile id 
		public boolean validateMobileId(long mobId)
		{
			String str = Long.toString(mobId);
		if(Pattern.matches("\\d{4}",str))
			return true;
		else
			return false;
		}


		public boolean authenticateAdmin(String username, String password) throws EmployeeException 
		{
		return daoObj.authenticateAdmin(username, password);
		}
		


		public boolean authenticateUser(String username, String password) throws EmployeeException {
			return daoObj.authenticateUser(username, password);
		}



		public EmployeeDetails viewEmployeeDetails(String username) throws EmployeeException {
			// TODO Auto-generated method stub
			return daoObj.viewEmployeeDetails(username);
		}

		public List<EmployeeDetails> getAllEmployees() throws EmployeeException {
			// TODO Auto-generated method stub
			return daoObj.getAllEmployees();
		}

		public void DeleteEmployee(String EmployeeId) throws EmployeeException {
			daoObj.DeleteEmployee(EmployeeId);
			
		}
		public EmployeeDetails addEmployeeDetails(EmployeeDetails details) throws EmployeeException{
			return daoObj.addEmployeeDetails(details);
		}
		public boolean vaidateEmpId(String id) {
			if(Pattern.matches("\\d{6}",id))
				return true;
			else
				return false;	
		}

		public List<EmployeeDetails> searchBy(String typeOfsearch, String temp) throws EmployeeException {
			// TODO Auto-generated method stub
			return daoObj.searchBy(typeOfsearch,temp);
			
		}
		public boolean validateFirstName(String employeeFirstName) {
			String pattern="[A-Z][a-z\\s]{1,25}";
			if(Pattern.matches(pattern, employeeFirstName))
			{
			return true;
			}
			else
			{
				return false;
			}
		}
		public boolean validateLastName(String employeeLastName) {
			String pattern="[A-Z][a-z\\s]{1,25}";
			if(Pattern.matches(pattern, employeeLastName))
			{
			return true;
			}
			else
			{
				return false;
			}
		}
		public boolean validateDOB(String employeeDOB1) {
			//String pattern="(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\\d\\d";
			String pattern="(0[1-9]|[12][0-9]|3[01])[- /.][a-zA-Z]{3}[- /.](19|20)\\d\\d";
			if(Pattern.matches(pattern, employeeDOB1))
			{
				return true;
			}
			else
			{
				return false;
			}
			/*DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			String dateStr = employeeDOB.format(dateTimeFormatter);
			String pattern="(19|20)\\d\\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])";
			if(Pattern.matches(pattern, dateStr))
			{
				return true;
			}
			else
			{
				return false;
			}*/
			/*LocalDate sysdate=LocalDate.now();
			 DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");  
             String strDate = dateFormat.format(employeeDOB);
			
			long diff = employeeDOB.getTime() - sysdate.getTime();
	        long diffSeconds = diff / 1000 % 60;
	        long diffMinutes = diff / (60 * 1000) % 60;
	        long diffHours = diff / (60 * 60 * 1000);
	        int diffInDays = (int) ((employeeDOB.getTime() - employeeDateOfJoining.getTime()) / (1000 * 60 * 60 * 24));
		
			if(employeeDOB.isBefore(sysdate))
			{
				return true;
			}
			else
			{
				return false;
			}
			if((LocalDate.parse(strDate , DateTimeFormatter.ofPattern( "dd-MM-yyyy" ) )
		    .isBefore( LocalDate.now( ZoneId.of( "IST" ) ) ))==true)
			{
				
			Date sysdate1=new Date();
			if(employeeDOB.before(sysdate1))
				{
					return true;
				}
				else
				{
					System.out.println("Enter the date before today");
					return false;
				}*/
		}
		public boolean validateDeptId(long employeeDeptId) {	
			 String pattern ="[0-9]{4}";
			 String employeeDeptId1=Long.toString(employeeDeptId);
			 if(Pattern.matches(pattern, employeeDeptId1))
				{
				 return true;
				}
				else
				{
					return false;
				}
		}
		public boolean valiadateGrade(String employeeGrade) {
			
			 String pattern ="[M][0-9]";	
			 if(Pattern.matches(pattern, employeeGrade))
				{
					return true;
				}
				else
				{
					return false;
				}
		}
		public boolean valiadateDesignation(String employeeDesignation) {
			return true;
		}
		public boolean valiadateBasic(long employeeBasic) {
			return true;
		}
		public boolean valiadateGender(String employeeGender) {
			 String pattern = "^F|M$";		
			 if(Pattern.matches(pattern, employeeGender))
				{
					return true;
				}
				else
				{
					return false;
				}
		}
		public boolean valiadateMartialStatus(String employeeMartialStatus) {
			 String pattern = "^Single|Married|Divorced|Separated|Widowed$";		
			 if(Pattern.matches(pattern, employeeMartialStatus))
				{
					return true;
				}
				else
				{
					return false;
				}
		}
		/*public boolean valiadateAddress(String employeeAddress) {
			return true;
		}*/
		public boolean valiadatePhn(long employeeContactNumber) {
			 String pattern = "[7-9][0-9]{9}";
			 String employeeContactNumberP= Long.toString(employeeContactNumber);
			 if(Pattern.matches(pattern, employeeContactNumberP))
				{
					return true;
				}
				else
				{
					return false;
				}
		}

		/*public ArrayList<Integer> deptIds() throws EmployeeException{
			return ArrayList<Integer>;
		}*/

		public void addUser() {
			// TODO Auto-generated method stub
			
		}

		public UserMaster addUserDetails(UserMaster udetails) throws EmployeeException {
			return daoObj.addUserDetails(udetails);
			
		}

		public boolean validateUserName(String userName) {
			String pattern = "[a-zA-Z0-9]{5,20}";
			 if(Pattern.matches(pattern, userName))
				{
					return true;
				}
				else
				{
					return false;
				}
		}

		public boolean validateUserPassword(String userPassword) {
			/*Explanations:

				(?=.*[0-9]) a digit must occur at least once
				(?=.*[a-z]) a lower case letter must occur at least once
				(?=.*[A-Z]) an upper case letter must occur at least once
				(?=.*[@#$%^&+=]) a special character must occur at least once
				(?=\\S+$) no whitespace allowed in the entire string
				.{8,} at least 8 characters*/
			String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}";;
			 if(Pattern.matches(pattern, userPassword))
				{
					return true;
				}
				else
				{
					return false;
				}
		}

		/*public boolean validateUserType(String userType) {
			String pattern = "^admin|Admin|ADMIN|EMPLOYEE|Employee|employee$";
			 if(Pattern.matches(pattern, userType))
				{
					return true;
				}
				else
				{
					return false;
				}
		}*/

		public ArrayList<String> getGrades() throws EmployeeException {
			return daoObj.getGrades() ;
		}

		public ArrayList<String> getDeptId() throws EmployeeException {
			return daoObj.getDeptId();
		}
		EmployeeDetails details=new EmployeeDetails();
		public boolean validateDOJ(String employeeDOJ1) {
					//String pattern="(19|20)\\d\\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])";
			String pattern="(0[1-9]|[12][0-9]|3[01])[- /.][a-zA-Z]{3}[- /.](19|20)\\d\\d";
					if(Pattern.matches(pattern, employeeDOJ1))
					{
						/*SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
						 Date d1 = null;
						    Date d2 = null;
						    try {
						        d1 = format.parse(details.getEmployeeDOB());
						        d2 = format.parse(employeeDOJ1);
						    } catch (ParseException e) {
						        e.printStackTrace();
						    }*/
						   /* long diff = d2.getTime() - d1.getTime();
						    long diffSeconds = diff / 1000 % 60;
						    long diffMinutes = diff / (60 * 1000) % 60;
						    long diffHours = diff / (60 * 60 * 1000);
						    System.out.println("Time in seconds: " + diffSeconds + " seconds.");
						    System.out.println("Time in minutes: " + diffMinutes + " minutes.");
						    System.out.println("Time in hours: " + diffHours + " hours.");*/
						    /*int diffInDays = (int) ((d1.getTime() - d2.getTime()) / (1000 * 60 * 60 * 24));
						   if(diffInDays>=6570)
						   {
						    return true;
						   }
						   else
						   {
							   System.out.println("enter valid Date of Joining");
						   }*/
						 return true;  
					}
					else
					{
						return false;
					}
		}

		/*public boolean calculate(String employeeDOJ1) {
			SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
			 Date d1 = null;
			    Date d2 = null;
			    try {
			        d1 = format.parse(details.getEmployeeDOB());
			        d2 = format.parse(employeeDOJ1);
			    	} 
			    catch (ParseException e) {
			        e.printStackTrace();
			    	}
			    int diffInDays = (int) ((d1.getTime() - d2.getTime()) / (1000 * 60 * 60 * 24));
				   if(diffInDays>=6570)
				   {
				    return true;
				   }
				   else
				   {
					   System.out.println("enter valid Date of Joining");
					   return false;
				   }
		}*/
}
