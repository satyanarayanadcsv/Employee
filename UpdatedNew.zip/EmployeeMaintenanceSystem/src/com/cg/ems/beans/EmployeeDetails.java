package com.cg.ems.beans;

import java.time.LocalDate;
import java.util.Date;


public class EmployeeDetails 
{
	private String EmployeeId;
	private String EmployeeFirstName;
	private String EmployeeLastName;
	private String EmployeeDOB;
	private String EmployeeDateOfJoining;
	private long EmployeeDeptId;
	private String EmployeeGrade;
	private String EmployeeDesignation;
	private long EmployeeBasic;
	private String EmployeeGender;
	private String EmployeeMartialStatus;
	private String EmployeeAddress;
	private long EmployeeContactNumber;
	public String getEmployeeId() {
		return EmployeeId;
	}
	public void setEmployeeId(String employeeId) {
		EmployeeId = employeeId;
	}
	public String getEmployeeFirstName() {
		return EmployeeFirstName;
	}
	public void setEmployeeFirstName(String employeeFirstName) {
		EmployeeFirstName = employeeFirstName;
	}
	public String getEmployeeLastName() {
		return EmployeeLastName;
	}
	public void setEmployeeLastName(String employeeLastName) {
		EmployeeLastName = employeeLastName;
	}
	public String getEmployeeDOB() {
		return EmployeeDOB;
	}
	public void setEmployeeDOB(String employeeDOB1) {
		EmployeeDOB = employeeDOB1;
	}
	public String getEmployeeDateOfJoining() {
		return EmployeeDateOfJoining;
	}
	public void setEmployeeDateOfJoining(String employeeDateOfJoining2) {
		EmployeeDateOfJoining = employeeDateOfJoining2;
	}
	public long getEmployeeDeptId() {
		return EmployeeDeptId;
	}
	public void setEmployeeDeptId(long employeeDeptId2) {
		EmployeeDeptId = employeeDeptId2;
	}
	public String getEmployeeGrade() {
		return EmployeeGrade;
	}
	public void setEmployeeGrade(String employeeGrade) {
		EmployeeGrade = employeeGrade;
	}
	public String getEmployeeDesignation() {
		return EmployeeDesignation;
	}
	public void setEmployeeDesignation(String employeeDesignation) {
		EmployeeDesignation = employeeDesignation;
	}
	public long getEmployeeBasic() {
		return EmployeeBasic;
	}
	public void setEmployeeBasic(long employeeBasic) {
		EmployeeBasic = employeeBasic;
	}
	public String getEmployeeGender() {
		return EmployeeGender;
	}
	public void setEmployeeGender(String employeeGender) {
		EmployeeGender = employeeGender;
	}
	public String getEmployeeMartialStatus() {
		return EmployeeMartialStatus;
	}
	public void setEmployeeMartialStatus(String employeeMartialStatus) {
		EmployeeMartialStatus = employeeMartialStatus;
	}
	public String getEmployeeAddress() {
		return EmployeeAddress;
	}
	public void setEmployeeAddress(String employeeAddress) {
		EmployeeAddress = employeeAddress;
	}
	public long getEmployeeContactNumber() {
		return EmployeeContactNumber;
	}
	public void setEmployeeContactNumber(long employeeContactNumber) {
		EmployeeContactNumber = employeeContactNumber;
	}
	
	
	
	
	/*
	i.	ID(Can provide wild card search)	
	ii.	"First Na,me
	iii.	"Last Name"	(Can provide wild card search)
	iv.	Wild card search (? / *)
	�	? for a character
	�	* for  n characters
	v.	Department (Can choose one or more department at a time � Multiple choice)
	vi.	Grade (Multiple choice)
	vii.	Marital Status  */

}
