package com.cg.ems.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.ems.Exception.EmployeeException;
import com.cg.ems.beans.EmployeeDetails;
import com.cg.ems.beans.UserMaster;
import com.cg.ems.util.DBConnection;
public class EmployeeDaoImpl implements EmployeeDao 
{
	EmployeeDetails details=new EmployeeDetails();
	private Logger logger = Logger.getLogger(EmployeeDaoImpl.class);
	public EmployeeDetails addUser(EmployeeDetails details) throws EmployeeException {		
		return details;
	}
	public EmployeeDetails addEmployeeDetails(EmployeeDetails details) throws EmployeeException {
		PreparedStatement insertStmt=null;
		/*java.util.Date d1=details.getEmployeeDOB();
		java.sql.Date DO=new java.sql.Date(d1.getTime());
		java.util.Date d2=details.getEmployeeDateOfJoining();
		java.sql.Date DJ=new java.sql.Date(d2.getTime());*/
		/*System.out.println("before date");
		java.util.Date dateOfBirth=details.getEmployeeDOB();
		
		Date DOB=new java.sql.Date(dateOfBirth.getTime());
		System.out.println("DOB:");
		System.out.println(DOB);
		java.util.Date dateOfJoining=details.getEmployeeDateOfJoining();
		java.sql.Date DOJ=new java.sql.Date(dateOfJoining.getTime());
		System.out.println("DOj:");
		System.out.println(DOJ);*/
		Connection conn=DBConnection.getConnection();	
			System.out.println("connected");
			try {
				System.out.println("values to insert");
				insertStmt=conn.prepareStatement(IQueryMapper.INSERT_QUERY);
				System.out.println("continue");
				insertStmt.setString(1, details.getEmployeeFirstName());
				insertStmt.setString(2, details.getEmployeeLastName());
				insertStmt.setString(3, details.getEmployeeDOB());
				System.out.println(details.getEmployeeDOB());
				insertStmt.setString(4, details.getEmployeeDateOfJoining());
				insertStmt.setLong(5, details.getEmployeeDeptId());
				insertStmt.setString(6, details.getEmployeeGrade());
				insertStmt.setString(7, details.getEmployeeDesignation());
				insertStmt.setLong(8, details.getEmployeeBasic());
				insertStmt.setString(9, details.getEmployeeGender());
				insertStmt.setString(10, details.getEmployeeMartialStatus());
				insertStmt.setString(11, details.getEmployeeAddress());
				insertStmt.setLong(12, details.getEmployeeContactNumber());
				 int result=insertStmt.executeUpdate();
				 System.out.println("After inserting");
				if(result!=1)
				{
					System.out.println("values not inserted");
					throw new EmployeeException("cannot process further");
				}
				else
				{
					conn.commit();
				}
			} 
			catch (SQLException e)
			{
				System.out.println(e);
			}
			return details;
	}		
	@Override
	public boolean authenticateUser(String username, String password) throws EmployeeException {
		logger.info("Customer registration started");
		Connection conn;
		PreparedStatement insertStmt = null;
		ResultSet resultSet=null;
		String str=null;
		boolean status=false;
		try
		{
			conn=DBConnection.getConnection();
			insertStmt=conn.prepareStatement(IQueryMapper.VALIDATE_USER);
			insertStmt.setString(1,username);
			resultSet=insertStmt.executeQuery();
			if(resultSet.next())
				{		
					str=resultSet.getString(1);
					if(str.equals(password))
						status=true;	
					else
						System.out.println("wrong username/password...");
				}		
		}
		catch(EmployeeException e)
		{
			throw new EmployeeException("sorry not updated");
		}
		catch(SQLException e)
		{
			throw new EmployeeException("sorry not updated");
		}
		return status;
	}
	@Override
	public boolean authenticateAdmin(String username, String password) throws EmployeeException {
		// TODO Auto-generated method stub
		logger.info("Customer registration started");
		Connection conn;
		System.out.println("before");
		PreparedStatement insertStmt = null;
		ResultSet resultSet=null;
		String str=null;
		boolean status=false;
		try
		{
			conn=DBConnection.getConnection();
			System.out.println("connected");
			insertStmt=conn.prepareStatement(IQueryMapper.VALIDATE_ADMIN);
			insertStmt.setString(1,username);
			resultSet=insertStmt.executeQuery();
			if(resultSet.next())
				{		
					str=resultSet.getString(1);
					if(str.equals(password))
						status=true;	
					else
						System.out.println("wrong username/password...");
				}	
		}
		catch(EmployeeException e)
		{
			throw new EmployeeException("sorry not updated");
		}
		catch(SQLException e)
		{
			throw new EmployeeException("sorry not updated");
		}
		return status;
	}
	public EmployeeDetails viewEmployeeDetails(String username) throws EmployeeException {
		Connection conn;
		conn=DBConnection.getConnection();
		EmployeeDetails empbean = new EmployeeDetails();
		PreparedStatement insertStmt = null;
		ResultSet resultset = null;	
		EmployeeDetails employee = new EmployeeDetails();
		try
		{
			conn=DBConnection.getConnection();
			insertStmt=conn.prepareStatement(IQueryMapper.DISPLAY_DETAILS);
			insertStmt.setString(1,username);
			resultset=insertStmt.executeQuery();
			empbean=null;
			if(resultset.next()) {
				empbean.setEmployeeId(resultset.getString(1));
				empbean.setEmployeeFirstName(resultset.getString(2));
				empbean.setEmployeeLastName(resultset.getString(3));
				empbean.setEmployeeDOB(resultset.getString(4));
				empbean.setEmployeeDateOfJoining(resultset.getString(5));
				empbean.setEmployeeDeptId(resultset.getInt(6));
				empbean.setEmployeeGrade(resultset.getString(7));
				empbean.setEmployeeDesignation(resultset.getString(8));
				empbean.setEmployeeBasic(resultset.getInt(9));
				empbean.setEmployeeGender(resultset.getString(10));
				empbean.setEmployeeMartialStatus(resultset.getString(11));
				empbean.setEmployeeAddress(resultset.getString(12));
				empbean.setEmployeeContactNumber(resultset.getLong(13));
			}
		} 
		catch(SQLException e)
		{
			throw new EmployeeException("sorry not updated");
		}
			return empbean;
	}
	public List<EmployeeDetails> getAllEmployees() throws EmployeeException 
	{
		Connection conn;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement=null;		
		ArrayList<EmployeeDetails> employeeList= new ArrayList<EmployeeDetails>();	
		try
		{
			conn=DBConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.GET_ALLEmployees);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{	
				EmployeeDetails empbean=new EmployeeDetails();
				empbean.setEmployeeId(resultSet.getString(1));
				empbean.setEmployeeFirstName(resultSet.getString(2));
				empbean.setEmployeeLastName(resultSet.getString(3));
				empbean.setEmployeeDOB(resultSet.getString(4));
				empbean.setEmployeeDateOfJoining(resultSet.getString(5));
				empbean.setEmployeeDeptId(resultSet.getInt(6));
				empbean.setEmployeeGrade(resultSet.getString(7));
				empbean.setEmployeeDesignation(resultSet.getString(8));
				empbean.setEmployeeBasic(resultSet.getInt(9));
				empbean.setEmployeeGender(resultSet.getString(10));
				empbean.setEmployeeMartialStatus(resultSet.getString(11));
				empbean.setEmployeeAddress(resultSet.getString(12));
				empbean.setEmployeeContactNumber(resultSet.getLong(13));
				employeeList.add(empbean);	
			}	
		}
		catch(EmployeeException e)
		{
			throw new EmployeeException("sorry not updated");
		}
		catch(SQLException e)
		{
			throw new EmployeeException("sorry not updated");
		}
		return employeeList;
	}
	public void DeleteEmployee(String employeeId) throws EmployeeException 
	{
		Connection conn;
		ResultSet resultSet = null;
		PreparedStatement deletedCol = null;	
		try {
			conn=DBConnection.getConnection();
			deletedCol = conn.prepareStatement(IQueryMapper.DELETE_Employee);
			deletedCol.setString(1,employeeId);
			int result = deletedCol.executeUpdate();
		if (result != 1) 
		{
		logger.debug("values not inserted");
		throw new EmployeeException("Deletion failed");
		}
		else {
		conn.commit();
		System.out.println("Deleted employeee details...");
		}
		}
		catch (SQLException | EmployeeException e) {
		throw new EmployeeException("deletion not done");
		}
		}
	public List<EmployeeDetails> searchBy(String typeOfsearch, String temp) throws EmployeeException 
	{
		Connection conn;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement=null;				
		ArrayList<EmployeeDetails> employeeList= new ArrayList<EmployeeDetails>();
		System.out.println("type of search:" + typeOfsearch);
		System.out.println("search:" + temp);
		try
		{
			conn=DBConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.Search_BY_Type);
//			preparedStatement.setString(1,typeOfsearch);
			int num=Integer.parseInt(temp);
			preparedStatement.setInt(1,num);
			preparedStatement.setString(2,temp);
			preparedStatement.setString(3,temp);
			preparedStatement.setInt(4,num);
			preparedStatement.setString(5,temp);
			preparedStatement.setString(6,temp);		
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{	
				EmployeeDetails empbean=new EmployeeDetails();
				empbean.setEmployeeId(resultSet.getString(1));
				empbean.setEmployeeFirstName(resultSet.getString(2));
				empbean.setEmployeeLastName(resultSet.getString(3));
				empbean.setEmployeeDOB(resultSet.getString(4));
				empbean.setEmployeeDateOfJoining(resultSet.getString(5));
				empbean.setEmployeeDeptId(resultSet.getInt(6));
				empbean.setEmployeeGrade(resultSet.getString(7));
				empbean.setEmployeeDesignation(resultSet.getString(8));
				empbean.setEmployeeBasic(resultSet.getInt(9));
				empbean.setEmployeeGender(resultSet.getString(10));
				empbean.setEmployeeMartialStatus(resultSet.getString(11));
				empbean.setEmployeeAddress(resultSet.getString(12));
				empbean.setEmployeeContactNumber(resultSet.getLong(13));
				employeeList.add(empbean);	
			}	
		}
		
		catch(EmployeeException e)
		{
			throw new EmployeeException("sorry not updated");
		}
		catch(SQLException e)
		{
			throw new EmployeeException("sorry not updated");
		}
		return employeeList;
			
	}
	public UserMaster addUserDetails(UserMaster udetails) throws EmployeeException {
		PreparedStatement insertStmt=null;
		Connection conn=DBConnection.getConnection();	
			System.out.println("connected");
			try {
				System.out.println("values to insert");
				insertStmt=conn.prepareStatement(IQueryMapper.INSERT_USER_DETAILS_QUERY);
				System.out.println("continue");
				insertStmt.setString(1, udetails.getUserName());
				insertStmt.setString(2, udetails.getUserPassword());
				insertStmt.setString(3, udetails.getUserType());
				 int result=insertStmt.executeUpdate();
				if(result!=1)
				{
					System.out.println("values not inserted");
					throw new EmployeeException("cannot process further");
				}
				else
				{
					insertStmt=conn.prepareStatement(IQueryMapper.Get_EMPID);
					ResultSet result1 = insertStmt.executeQuery();
					if(result1.next())
					{
						long id=result1.getLong(1);
						System.out.println(" your Employee id "+id);
				}			
					else
						{
						throw new EmployeeException("cannot process further");
						}		
					conn.commit();
				}
			} 
			catch (SQLException e)
			{
				System.out.println(e);
			}
			return udetails;
	}
	public ArrayList<String> getGrades() throws EmployeeException {
		Connection conn ;
		PreparedStatement ps=null;
		ResultSet resultset = null;
		ArrayList<String> list=new ArrayList<String>();
		try {
				conn =DBConnection.getConnection();
			ps=conn.prepareStatement(IQueryMapper.Grade_query);
			resultset=ps.executeQuery();
			System.out.println("available grades are");
			while(resultset.next())
			{	
				list.add(resultset.getString("Grade_Code"));
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
		}
		return list;
	}
	public ArrayList<String> getDeptId() throws EmployeeException  {
		Connection conn ;
		PreparedStatement ps=null;
		ResultSet resultset = null;
		ArrayList<String> list=new ArrayList<String>();
		try {
				conn =DBConnection.getConnection();
			ps=conn.prepareStatement(IQueryMapper.Dept_Id_query);
			resultset=ps.executeQuery();
			System.out.println("available Department Id's are");
			while(resultset.next())
			{	
				list.add(resultset.getString("Dept_ID"));
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
		}
		return list;
	}
}