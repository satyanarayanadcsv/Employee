package com.cg.ems.dao;

import com.cg.ems.Exception.EmployeeException;
import com.cg.ems.beans.EmployeeDetails;


public interface EmployeeDao 
{
	public EmployeeDetails addEmployeeDetails(EmployeeDetails details) throws EmployeeException;
	public boolean authenticateUser(String username, String password) throws EmployeeException;
	public boolean authenticateAdmin(String username, String password) throws EmployeeException ;
}
