package com.cg.ems.dao;

public interface IQueryMapper {
	public static final String VALIDATE_ADMIN = "SELECT PASSWORD FROM ADMIN_DETAILS WHERE USERNAME= ?";
	public static final String VALIDATE_USER = "SELECT USER_PASSWORD FROM User_Master WHERE USER_NAME= ?";
	public static final String DISPLAY_DETAILS=" select * from employee where emp_id=(select user_id from user_master where User_Name=?)";
	public static final String GET_ALLEmployees = "select * from employee";
	public static final String DELETE_Employee = "Delete from Employee where Emp_ID=?";
	public static final String Search_BY_Type="select * from employee where(Emp_ID=? or Emp_First_Name=?  or Emp_Last_Name=? or Emp_Dept_ID=? or Emp_Grade=? or Emp_Marital_Status=? );";
	public static final String INSERT_QUERY =" insert into Employee values(Employee_Id_Seq.currval,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String INSERT_USER_DETAILS_QUERY = "insert into User_Master values(Employee_Id_Seq.nextval,?,?,?)";
	public static final String Grade_query = "select Grade_Code from Grade_Master";
	public static final String Dept_Id_query = "select Dept_ID from Department";
	public static final String Get_EMPID = "select Employee_Id_Seq.currval from dual ";
}
