package com.cg.ems.ui;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.SynchronousQueue;

import com.cg.ems.Exception.EmployeeException;
import com.cg.ems.beans.EmployeeDetails;
import com.cg.ems.beans.UserMaster;
import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.service.EmployeeServiceImpl;
public class MainUI {
	private static Scanner in;
	private String EmployeeId;
	private String EmployeeFirstName;
	private String EmployeeLastName;
	//private static Date EmployeeDOB ;
	//private static Date EmployeeDateOfJoining;
	private long EmployeeDeptId;
	private String EmployeeGrade;
	private String EmployeeDesignation;
	private long EmployeeBasic;
	private String EmployeeGender;
	private String EmployeeMartialStatus;
	private String EmployeeAddress;
	private long EmployeeContactNumber;
	static String EmployeeDOB1;
	static String EmployeeDOJ1;
	static EmployeeDetails edetails=new EmployeeDetails ();
	static EmployeeServiceImpl service= new EmployeeServiceImpl();
	public static void main(String[] args) throws EmployeeException
	{
		in = new Scanner(System.in);
		System.out.println("Welocome To Trainer Regsitration Portal");
		String choice = "null";
		
		while (!choice.equals("3")) 
		{	
			System.out.println("-----------------------------------");
			System.out.println("      * Enter your choice *        ");
			System.out.println("1) Admin interface");
			System.out.println("2) Employee  interface");
			System.out.println("3) Exit ");
			System.out.println("-----------------------------------");
			choice = in.next().trim();
			switch (choice) 
			{
			case "1": 
					Admin();
					break;
			case "2":
				Employee();
				System.out.println("Thank you.... Program terminated");
				System.exit(0);
				break;		
			default:
				System.out.println("WRONG CHOICE chosen...Please enter a valid choice\n");
			}
		}
		System.out.println("Thank you.... program terminated");
	}
	
private static void Admin() throws EmployeeException
	{
	 EmployeeServiceImpl imp = new EmployeeServiceImpl();
	 System.out.println("Authentication Required, Please provide your Login credentials\n");
	 boolean b1;
	 boolean status=true;
	 
	 while(status)
	 {
		 System.out.println("Enter your username");
		 String username = in.next();
		 System.out.println("Enter your password");
		 String password = in.next();
	     if (b1=imp.authenticateAdmin(username, password))
	     {
		 System.out.println("\nWelcome " + username);
		 int choice2 = 0;
		 while (choice2 != 6) 
		 {
			 System.out.println(" \nEnter your choice:\n");
			 System.out.println(" 1.Add Employee");
			 System.out.println(" 2.View Employees");
			 System.out.println(" 3.Search Employee");
			 System.out.println(" 4.Delete Employee");
			 System.out.println(" 5.Modify Employee");
			 System.out.println(" 6.Exit\n");
			 choice2 = in.nextInt();
	   
			 switch (choice2) 
			 {
	   			case 1: try {
					addNewEmployee();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}  break;
	   			case 2: viewEmployees();   break;
	   			case 3: searchEmployee();  break;
	   			case 4: DeleteEmployee();  break;
	   			case 5: modifyEmployee();  break;
	   			case 6: System.out.println("Thank you exited....");
	   					System.exit(0);
	   			default: System.out.println("Wrong choice chosen... enter valid one");
			 }
	    }
	}
	 if(b1)
	 {
	 System.out.println("Thank you for registering.....!\n"); status=false;
	 }
	 else
		 System.out.println("Enter valid admin credentials...");
	}
	}
	


	private static void Employee() throws EmployeeException 
	{
		EmployeeServiceImpl serv = new EmployeeServiceImpl();
		 System.out.println("Authentication Required, Please provide your Login credentials\n");
		 System.out.println("Enter your username");
		 String username = in.next();
		 System.out.println("Enter your password");
		 String password = in.next();
		 boolean b1;
		 if (b1=serv.authenticateUser(username, password))
		 {
		 
		  EmployeeDetails emp= serv.viewEmployeeDetails(username);	 
		  if(emp!=null)
		  {
		  System.out.println("\nWelcome " + username);
		  System.out.println("Employee Id 	  : " + emp.getEmployeeId());
		  System.out.println("Employee   	  : " + emp.getEmployeeFirstName());
		  System.out.println("Designation 	  : " + emp.getEmployeeDesignation());
		  System.out.println("Dept Id		  : " + emp.getEmployeeDeptId());
		  System.out.println("Gender		  : " + emp.getEmployeeGender());
		  System.out.println("Contact Number  : " + emp.getEmployeeContactNumber());
		  }
		  else
			  System.out.println("No details availabale for " + username);
		  
		  
		  
		  int choice2 = 0;
		   while (choice2 != 3) {
		   System.out.println(" \nEnter your choice:"); 
		   System.out.println(" 1.Search Employee");
		   System.out.println(" 2.Exit\n");
		   choice2 = in.nextInt();
		   
		   switch (choice2) 
		   {
		   case 1: searchEmployee();  break;
		   case 2: System.out.println("Thank you exited....");
			   	   System.exit(0);
		   default: System.out.println("Wrong choice chosen... enter valid one");
		   }
		   }	
		}
		 
		 if(b1)
		 System.out.println("Thank you for registering.....!\n");
		 else
			 System.out.println("not registered...");
	}
	
	
	private static void modifyEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
	
	}


		private static void DeleteEmployee() throws EmployeeException{
			EmployeeServiceImpl serv = new EmployeeServiceImpl();
			boolean status=true;
			
			while(status)
			{
			System.out.println("Enter employee Id");
			String id=in.next();
			if(serv.vaidateEmpId(id))
			{
			service.DeleteEmployee(id);
			System.out.println("Succesfuly deleted employeee with id: " + id);
			status=false;
			}
			else{
				System.out.println("employee id should contain only numbers..");
			}
			}
		}

		static EmployeeServiceImpl serv = new EmployeeServiceImpl();
		
		private static void searchEmployee() throws EmployeeException 
		{
			in = new Scanner(System.in);
			//EmployeeServiceImpl serv = new EmployeeServiceImpl();
			System.out.println("Welocome To Trainer Regsitration Portal");
			String choice = "null";
			String temp=null;
			List<EmployeeDetails> emplist =null;
	/*		
			i.	ID(Can provide wild card search)	
			ii.	"First Name"	(Can provide wild card search)
			iii.	"Last Name"	(Can provide wild card search)
			iv.	Wild card search (? / *)
			�	? for a character
			�	* for  n characters
			v.	Department (Can choose one or more department at a time � Multiple choice)
			vi.	Grade (Multiple choice)
			vii.	Marital Status (Multiple choice)

		*/	
			System.out.println("enter search type");
				System.out.println("1) Search by ID ");
				System.out.println("2) Search by first name");
				System.out.println("3) Search by last name");
				System.out.println("4) Search by department name");
				System.out.println("5) Search by grade");
				System.out.println("6) Search by martial status");
		
				
				
				choice = in.next().trim();
				switch (choice) 
				{
				case "1": System.out.println("Enter id:");
							temp=in.next();
							
							emplist=serv.searchBy("EMP_ID",temp);break;
				case "2": System.out.println("Enter first name:");
							temp=in.next();
							
							emplist=serv.searchBy("EMP_FIRST_NAME",temp);break;
				case "3": System.out.println("Enter last name:");
							temp=in.next();
							emplist=serv.searchBy("EMP_LAST_NAME",temp);break;
				case "4": System.out.println("Enter department:");
							temp=in.next();
							emplist=serv.searchBy("Dept_Name",temp);break;
				case "5": System.out.println("Enter grade:");
							temp=in.next();
							emplist=serv.searchBy("Grade_Code",temp);break;
				case "6": System.out.println("Enter martial status:");
							temp=in.next();
							emplist=serv.searchBy("Emp_Marital_Status",temp);break;
				default:
					System.out.println("WRONG CHOICE chosen...Please enter a valid choice\n");
				}
				
				if(emplist!=null)
				{
				for(EmployeeDetails emp: emplist)
				{
					System.out.print(emp.getEmployeeId()+ " ");
					  System.out.print(emp.getEmployeeFirstName()+ " ");
					  System.out.print(emp.getEmployeeDesignation()+ " ");
					  System.out.print(emp.getEmployeeDeptId()+ " ");
					  System.out.print(emp.getEmployeeGender()+ " ");
					  System.out.print(emp.getEmployeeContactNumber()+ " ");
					  System.out.print(emp.getEmployeeBasic()+ " ");
					  System.out.print(emp.getEmployeeMartialStatus()+ " ");
					  System.out.print(emp.getEmployeeDateOfJoining()+ " ");
					  System.out.print(emp.getEmployeeDOB()+ " ");
					  System.out.println();
				}
				}
				else
					System.out.println("There are no details for your search");	
		}

		private static void viewEmployees() throws EmployeeException {
			List<EmployeeDetails> employeesList = new ArrayList<EmployeeDetails>();
			employeesList = service.getAllEmployees();
			if(employeesList!=null)
			{
				
			for(EmployeeDetails emp : employeesList)
			{
				 System.out.print(emp.getEmployeeId()+ " ");
				  System.out.print(emp.getEmployeeFirstName()+ " ");
				  System.out.print(emp.getEmployeeDesignation()+ " ");
				  System.out.print(emp.getEmployeeDeptId()+ " ");
				  System.out.print(emp.getEmployeeGender()+ " ");
				  System.out.print(emp.getEmployeeContactNumber()+ " ");
				  System.out.print(emp.getEmployeeBasic()+ " ");
				  System.out.print(emp.getEmployeeMartialStatus()+ " ");
				  System.out.print(emp.getEmployeeDateOfJoining()+ " ");
				  System.out.print(emp.getEmployeeDOB()+ " ");
				  System.out.println();
			}
				System.out.println();
			}
			else {
				System.out.println("There are no employees...");
			}
	
	}
		private static void addNewEmployee() throws ParseException {
			UserMaster udetails=new UserMaster();
			while(true)
			{
				System.out.println("Enter UserName");
				String  userName=in.next();
				if((serv.validateUserName(userName))==true)
				{
					udetails.setUserName(userName);
					break;
				}
				else
				{
					System.out.println("Enter Valid User Name");
				}
			}
			while(true)
			{
				System.out.println("Enter Password");
				String userPassword=in.next();
				if((serv.validateUserPassword(userPassword))==true)
				{
					udetails.setUserPassword(userPassword);
					break;
				}
				else
				{
					System.out.println("Enter Valid Password");
				}
			}
			while(true)
			{
				System.out.println("Enter User-Type");
				System.out.println("1.Admin");
				System.out.println("2.Employee");
				String userType=in.next();
				switch(userType)
				{
				case "1": 
					udetails.setUserType("Admin");
					break;
				case "2":
					udetails.setUserType("Employee");
					break;
				default:
					System.out.println("Invalid User");
				}
				break;
			}
			try {
				serv.addUserDetails(udetails);
			} catch (EmployeeException e1) {
				e1.printStackTrace();
			}
			while(true)
			{
				System.out.println("Enter First Name");
				String  EmployeeFirstName=in.next();
				if((serv.validateFirstName(EmployeeFirstName))==true)
				{
					edetails.setEmployeeFirstName(EmployeeFirstName);
					break;
				}
				else
				{
					System.out.println("First Name Not Valid");
				}
			}
			while(true)
			{
				System.out.println("Enter Last Name");
				String  EmployeeLastName=in.next();
				if((serv.validateLastName(EmployeeLastName))==true)
				{
					edetails.setEmployeeLastName(EmployeeLastName);
							break;
				}
				else
				{
					System.out.println("Last Name Not Valid");
				}	
			}
			while(true)
			{
				System.out.println("Enter Date of Birth");
				System.out.println("date format: dd-mmm-yyyy");
				EmployeeDOB1=in.next();
				if((serv.validateDOB(EmployeeDOB1))==true)
				{
					System.out.println(EmployeeDOB1);
					edetails.setEmployeeDOB(EmployeeDOB1);
					break;
				}
				else
				{
					System.out.println("DOB not valid");
				}
			}
			while(true)
			{
				System.out.println("Enter Dateof Joining");
				EmployeeDOJ1=in.next();
				if((serv.validateDOJ(EmployeeDOJ1))==true)
				{
					edetails.setEmployeeDateOfJoining(EmployeeDOJ1);
					break;
				}
				else
				{
					System.out.println("DOJ is Not valid ");
				}
			}
			while(true)
			{
				ArrayList <String> deptList=new ArrayList <String>();
				try {
					deptList=serv.getDeptId();
				} catch (EmployeeException e) {
					e.printStackTrace();
				}
				System.out.println(deptList);
				System.out.println("Enter Department Id");
				long EmployeeDeptId=in.nextLong();
				if((serv.validateDeptId(EmployeeDeptId))==true)
				{
					edetails.setEmployeeDeptId(EmployeeDeptId);
					break;
				}
				else
				{
					System.out.println("Department Id Not Valid");
				}	
			}
			while(true)
			{
				ArrayList <String> gradelist=new ArrayList <String>();
				try {
					gradelist=serv.getGrades();
				} catch (EmployeeException e) {
					e.printStackTrace();
				}
				System.out.println(gradelist);
				System.out.println("Enter Employee Grade");
				String EmployeeGrade=in.next();
				if((serv.valiadateGrade(EmployeeGrade))==true)
				{
					edetails.setEmployeeGrade(EmployeeGrade);
					break;
				}
				else
				{
					System.out.println("Grade Not valid");
				}	
			}
			while(true)
			{
				System.out.println("Enter Designation:");
				String EmployeeDesignation=in.next();
				if((serv.valiadateDesignation(EmployeeDesignation))==true)
				{
					edetails.setEmployeeDesignation(EmployeeDesignation);
					break;
				}
				else
				{
					System.out.println("Designation Not valid");
				}
			}
			while(true)
			{
				System.out.println("Enter Employee Basic");
				long EmployeeBasic=in.nextLong();
				if((serv.valiadateBasic(EmployeeBasic))==true)
				{
					edetails.setEmployeeBasic(EmployeeBasic);
					break;
				}
				else
				{
					System.out.println("Basic Not valid");
				}
			}
			while(true)
			{
			System.out.println("Enter gender Either F' or 'M' ");	
			String EmployeeGender=in.next();
			EmployeeGender.toLowerCase();
				if((serv.valiadateGender(EmployeeGender))==true)
				{
					edetails.setEmployeeGender(EmployeeGender);
					break;
				}
				else
				{
					System.out.println("gender Not valid");
				}
			}
			while(true)
			{
				System.out.println("Enter Marital status");
				String EmployeeMartialStatus=in.next();
				if((serv.valiadateMartialStatus(EmployeeMartialStatus))==true)
				{
					edetails.setEmployeeMartialStatus(EmployeeMartialStatus);
					break;
				}
				else
				{
					System.out.println("Marital Status Not valid");
				}
			}
			System.out.println("Enter Employee Address");
			String EmployeeAddress=in.next();
			edetails.setEmployeeAddress(EmployeeAddress);
			while(true)
			{
				System.out.println("Enter Employee Phn Number");
				long EmployeeContactNumber=in.nextLong();
				if((serv.valiadatePhn(EmployeeContactNumber))==true)
				{
					edetails.setEmployeeContactNumber(EmployeeContactNumber);
					break;
				}
				else
				{
					System.out.println("Contact Number Not valid");
				}
			}		
			try {
				service.addEmployeeDetails(edetails);
			} catch (EmployeeException e) {
				e.printStackTrace();
			}
	}
}